public class OldMacDuck {
	public void quack() {
		System.out.println("Duck still says quack.");
	}
}