public class OldMacCow {
	public void moo() {
		System.out.println("Cow still says moo.");
	}
}