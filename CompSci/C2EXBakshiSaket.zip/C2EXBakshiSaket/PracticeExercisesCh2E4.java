/*
Saket Bakshi
Period 6
9/23/18
This program tells the value of mystery in the following code
*/
public class PracticeExercisesCh2E4
{
	public static void main(String[] args)
	{
			int mystery = 1;
			mystery = 1 - 2 * mystery; //subtracts twice the original value of mystery from mystery
			mystery = mystery + 1; 
			System.out.println(mystery); //The value of mystery is 0 
	}
}