/*
Saket Bakshi
Period 6
9/23/18
This program will declare and initialize variables for holding the price and description of an article that is available for sale.
*/
public class PracticeExercisesCh2E3
{
	public static void main(String[] args)
	{
		double articlePrice = 6.50;
		String articleDescription = "Potatoes";
	}
}