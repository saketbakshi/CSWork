/** Saket Bakshi. 3/4/19. Period 6. This is used for question 1 of Chapter 10.
	Creates a Measurable interface to be used to obtain measures.
*/
public interface Measurable
{
	/**
		obtains a measure of a Measurable object
	*/
	double getMeasure();
}