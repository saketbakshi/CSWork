/* Saket Bakshi, Period 6
Question 1.1 of Ch 3 project. This program creates an empty class for a door class.
*/
public class Door
{
	
}