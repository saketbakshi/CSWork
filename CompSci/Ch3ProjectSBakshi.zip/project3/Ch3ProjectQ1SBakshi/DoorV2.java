/* Saket Bakshi, Period 6
Question 1.2 of Ch 3 project. This program creates instance variables for a door class.
*/
public class DoorV2
{
	private String name;
	private String state;
}