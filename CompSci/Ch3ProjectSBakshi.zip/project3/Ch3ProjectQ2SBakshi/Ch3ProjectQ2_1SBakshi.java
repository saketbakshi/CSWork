/* Saket Bakshi, Period 6
Question 2.1 of Ch 3 project. This program prints ideas of methods for a vendingmachine class.
*/

public class Ch3ProjectQ2_1SBakshi
{
	public static void main(String[] args)
	{
		System.out.println("Methods for cans could be:\ngetCans(), which returns the number of cans in the machine\naddCans(), which adds a number of cans to a machine\nbuySoda(), which removes a can from the machine");
		System.out.println("Methods for tokens could be:\ngetTokens(), which returns how many tokens the machine has\nremoveTokens(), to empty the machine\nbuySoda(), with an explicit parameter for number of tokens added");	
	}
}
