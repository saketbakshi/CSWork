/* Saket Bakshi, Period 6
Question 4.1 of Ch 3 project. This program prints the number
of classes I would use to print several cars and houses.
*/

public class Ch3ProjectQ4_1SBakshi
{
	public static void main(String[] args)
	{
		System.out.println("I would have a class for the frame, a class for making the components, a class for making the cars, and a class for making the houses.");
	}
}