/* Saket Bakshi, Period 6
Question 3.1 of Ch 3 project. This program prints a class name for a postcard sender.
*/

public class Ch3ProjectQ3_1SBakshi
{
	public static void main(String[] args)
	{
		System.out.println("A black box name could be \"Postcard\"");
	}
}