/*
	Saket Bakshi
	Period 6
	8/29/18

	This program will print out three movie titles on three separate lines

*/
public class PracticeExercisesCh1E11 
{
	public static void main(String[] args)
	{
		System.out.println("Batman Begins \nThe Dark Knight \nThe Dark Knight Rises");
	} // \n makes a new line in the same line of code
}