/*
	Saket Bakshi
	Period 6
	8/29/18

	This program will print my name in large letters with asterisks

*/
public class PracticeExercisesCh1E6 
{
	public static void main(String[] args)
	{
		System.out.println(" ***     *    *   * ***** *****");
		System.out.println("*   *   * *   *  *  *       *  ");
		System.out.println("*      *   *  * *   *       *  ");
		System.out.println(" ***  ******* **    ***     *  ");
		System.out.println("    * *     * **    *       *  ");
		System.out.println("*   * *     * * *   *       *  ");
		System.out.println(" ***  *     * *  *  *****   *  ");
	}
}