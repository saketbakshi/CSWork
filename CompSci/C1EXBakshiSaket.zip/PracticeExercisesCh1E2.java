/*
	Saket Bakshi
	Period 6
	8/29/18

	This program will take them sum of integers 1 through 10

*/
public class PracticeExercisesCh1E2 
{
	public static void main(String[] args)
	{
		System.out.println(1+2+3+4+5+6+7+8+9+10); // prints out the sum
	}
}