import java.util.Scanner;

public class CBT028BakshiSaket
{
	public static void main(String[] args)
	{
		Scanner key = new Scanner(System.in);
		int secret, guess;

		secret = 1 + (int)(Math.random()*10);

		System.out.println("I have chosen a number between 1 and 10. Try to guess it.");
		System.out.print("Your guess: ");
		guess = key.nextInt();

		while(secret != guess)
		{
			System.out.println("That is incorrect. Guess again.");
			System.out.print("Your guess: ");
		}

		System.out.println("That's right! You're a good guesser.");
	}
}