public class Lab1P6BakshiS
{
	public static void main(String[] args)
	{
		System.out.println("\n  *        (__)");
        System.out.println("   \\       (oo)");
        System.out.println("    \\-------\\/");
        System.out.println("    /|      |\\");
        System.out.println("   //||----||\\\\");
        System.out.println("   ~ ~~    ~~ ~");
        System.out.println("    Cow walking");
        System.out.println("\n");
        System.out.println("          (__)");
        System.out.println("          (oo)");
        System.out.println("   /-------\\/");
        System.out.println("  / \\      /");
        System.out.println(" *   \\\\--//");
        System.out.println("      ~  ~");
        System.out.println("    Cow running");
        System.out.println("\n");
        System.out.println("          (__)");
        System.out.println("          (oo)");
        System.out.println("   /-------\\/");
        System.out.println("  / \\      \\");
        System.out.println(" *   \\\\----\\\\");
        System.out.println("      ~     ~");
        System.out.println("    Cow braking");
        System.out.println("");
        System.out.println("");
        System.out.println("           (__)");
        System.out.println("           (--) ");
        System.out.println("     /------\\/");
        System.out.println("    /|     ||");
        System.out.println("   * ||----||");
        System.out.println("     ~~    ~~");
        System.out.println("    Cow after pulling ");
        System.out.println("       an all nighter");
	}
}