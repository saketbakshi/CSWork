public class Ch2ProjectQ1_1SBakshi
{
	public static void main(String[] args)
	{
		String test = "This is a Test";
		String smallTest = test.toLowerCase();

		System.out.print(smallTest);
	}
}