public class Ch2ProjectQ1_2SBakshi
{
	public static void main(String[] args)
	{
		String test = "This is a Test";
		String smallTest = test.toLowerCase();

		System.out.println(smallTest);

		String bigTest = smallTest.toUpperCase();
		System.out.println(bigTest);

		/* The original string did not come back. The new String statement will print
		an all capital statement */
	}
}