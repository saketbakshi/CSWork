public class Ch2ProjectQ3_1SBakshi
{
	public static void main(String[] args)
	{
		//the StringTokenizer class allows an application to break a string into tokens.
	}
}