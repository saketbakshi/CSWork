public class Ch2ProjectQ3_2SBakshi
{
	public static void main(String[] args)
	{
		/*
			The countTokens method calculates the number of times that the tokenizer's
			next method can be called before it generates an exception.
			The nextToken method returns the next token from the string tokenizer.
		*/
	}
}