public class Ch2ProjectQ2_1SBakshi
{
	public static void main(String[] args)
	{
		//the concat method concatenates the specified string to the end of worked-on string
	}
}