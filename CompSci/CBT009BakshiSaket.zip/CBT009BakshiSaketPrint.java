public class CBT009BakshiSaketPrint
{
    public static void main(String[] args) 
    {
        System.out.println("Your height in m: 1.75");
        System.out.println("Your weight in kg: 73");
        System.out.println("Your BMI is 23.836734693877553");
    }

}