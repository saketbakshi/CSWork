public class CBT112Driver
{
	public static void main(String[] args) {
		//CBT112BakshiSaket r = new CBT112BakshiSaket();
		//r.length = 10;
		//r.width = 5;

		CBT112BakshiSaket r = new CBT112BakshiSaket(10,5);
		System.out.println("The area is " + r.getArea());
	}
}