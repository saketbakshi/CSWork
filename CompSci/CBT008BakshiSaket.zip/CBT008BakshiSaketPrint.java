import java.util.Scanner;

public class printCBT008BakshiSaket
{
    public static void main(String[] args) 
    {
        System.out.println("Hello. What is your name? Brick");
        System.out.println("Hi, Brick! How old are you? 25");
        System.out.println("So you're 25, eh? That's not old at all.");
        System.out.println("How much do you weigh, Brick? 192");
        System.out.println("192.0! Better keep that quiet. Finally, what's your income, Brick? 8.75");
        System.out.println("Hopefully that is 8.75 per hour and not per year!");
        System.out.println("Well, thanks for answering my rude questions, Brick.");
    }
}